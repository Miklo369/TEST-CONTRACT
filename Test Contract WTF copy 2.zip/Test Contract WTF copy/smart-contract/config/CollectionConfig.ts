import CollectionConfigInterface from '../lib/CollectionConfigInterface';
import whitelistAddresses from './whitelist.json';

const CollectionConfig: CollectionConfigInterface = {
  // The contract name can be updated using the following command:
  // yarn rename-contract NEW_CONTRACT_NAME
  // Please DO NOT change it manually!
  contractName: 'WTFTEST',
  tokenName: 'WTF TEST',
  tokenSymbol: 'WTFT',
  hiddenMetadataUri: 'ipfs://QmQpa6pvXGvs6n1tfrCDVmUE1hos8w6xiGPNi6A5bo9kAE/hidden.json',
  maxSupply: 5,
  whitelistSale: {
    price: 0,
    maxMintAmountPerTx: 1,
  },
  preSale: {
    price: 0.01,
    maxMintAmountPerTx: 2,
  },
  publicSale: {
    price: 0,
    maxMintAmountPerTx: 2,
  },
  contractAddress: "0x7b29aDE8b7d514915cA581E7A52a00f4153FADEa",
  openSeaSlug: 'my-nft-token',
  whitelistAddresses: whitelistAddresses,
};

export default CollectionConfig;
